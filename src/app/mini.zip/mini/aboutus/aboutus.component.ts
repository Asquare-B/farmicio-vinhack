import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aboutus1',
  templateUrl: './aboutus.component.html',
  styleUrls: ['./aboutus.component.css']
})
export class Aboutus1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
