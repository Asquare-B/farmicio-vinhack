import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chathome',
  templateUrl: './chathome.component.html',
  styleUrls: ['./chathome.component.css']
})
export class ChathomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
