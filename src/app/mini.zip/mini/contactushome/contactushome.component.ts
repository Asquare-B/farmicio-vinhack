import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contactushome',
  templateUrl: './contactushome.component.html',
  styleUrls: ['./contactushome.component.css']
})
export class ContactushomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
