import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-formcard',
  templateUrl: './formcard.component.html',
  styleUrls: ['./formcard.component.css']
})
export class FormcardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
