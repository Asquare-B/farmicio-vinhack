import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-formhome',
  templateUrl: './formhome.component.html',
  styleUrls: ['./formhome.component.css']
})
export class FormhomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
